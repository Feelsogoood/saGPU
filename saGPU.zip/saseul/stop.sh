#!/bin/bash

php src/saseul-script stop