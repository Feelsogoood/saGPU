#!/bin/bash

php src/saseul-script forcesync --peer 183.99.101.12
