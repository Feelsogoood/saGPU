#!/bin/bash

php src/saseul-script start
sleep 1
php src/saseul-script startmining