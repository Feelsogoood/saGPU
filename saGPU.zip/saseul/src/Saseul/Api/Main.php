<?php

namespace Saseul\Api;

use Core\Api;

class Main extends Api
{
}